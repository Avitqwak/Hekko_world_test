===============================
Hello World Package
===============================

|travis status|
|pypi status|
|docs status|
|coverage status|

Hello World test package

* Free software: MIT license
* Documentation: (COMING SOON!) https://hello-world-package-example.readthedocs.org.

Features
--------

* TODO


.. |travis status| image:: https://travis-ci.org/grantwilliams/hello-world-package-example.svg?branch=master
    :target: https://travis-ci.org/grantwilliams/hello-world-package-example

.. |pypi status| image:: https://img.shields.io/pypi/v/Hello-World-Package.svg
        :target: https://pypi.python.org/pypi/Hello-World-Package

.. |docs status| image:: https://readthedocs.org/projects/hello-world-package-example/badge/?version=latest
        :target: http://hello-world-package-example.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. |coverage status| image:: https://coveralls.io/repos/github/grantwilliams/hello-world-package-example/badge.svg?branch=master
        :target: https://coveralls.io/github/grantwilliams/hello-world-package-example?branch=master




History
-------

Pre-release



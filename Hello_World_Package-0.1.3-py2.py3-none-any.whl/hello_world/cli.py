from __future__ import print_function

def hello():
    return "Hello, World!"

def say_hello():
    print(hello())

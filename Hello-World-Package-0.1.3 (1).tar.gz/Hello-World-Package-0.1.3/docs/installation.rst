============
Installation
============

At the command line::

    $ pip install Hello-World-Package

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv Hello-World-Package
    $ pip install Hello-World-Package
